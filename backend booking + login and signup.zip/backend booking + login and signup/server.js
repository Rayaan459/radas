require("dotenv").config()
const jwt = require("jsonwebtoken")
const bcrypt = require("bcrypt")
const cookieParser = require('cookie-parser')
const express = require("express")
const db = require("better-sqlite3")("ourApp.db")
db.pragma("journal_mode = WAL")

const createTables = db.transaction(() => {
    // Create users table if not exists
    db.prepare(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
      )
    `).run()
    
    // Drop existing bookings table if it exists
    db.prepare(`DROP TABLE IF EXISTS bookings`).run()
    
// Create bookings table with new columns
db.prepare(`
  CREATE TABLE bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    description TEXT,
    quantity INTEGER NOT NULL DEFAULT 1,
    price DECIMAL(10, 2) NOT NULL DEFAULT 0,
    total_price DECIMAL(10, 2) NOT NULL DEFAULT 0,
    payment_status TEXT DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  )
`).run()
    
    console.log("Tables created successfully")
  })
  
  // Execute the function
  createTables()
// db ends here
const app = express()

app.set("view engine", "ejs")
app.use(express.urlencoded({extended: false}))
app.use(express.static("public"))
app.use(cookieParser())

app.use(function (req, res, next){
    res.locals.errors = []

    // try to decode cookie

    try{
        const decoded = jwt.verify(req.cookies.ourSimpleApp, process.env.JWTSECRET)
        req.user = decoded
    } catch(err) {
        req.user = false
    }

    res.locals.user = req.user
    console.log(req.user)

    next()
})

app.get("/", (req,res) => {
    if (req.user) {
       return res.render("dashboard")
    }
    
    res.render("homepage")
})

app.get("/login" , (req,res) => {
    res.render("login")
})


app.get("/logout", (req, res) => {
    res.clearCookie("ourSimpleApp")
    res.redirect("/")
})

app.post("/login", (req, res) =>{
    let errors = []

    if (typeof req.body.username !== "string") req.body.username = ""
    if (typeof req.body.password !== "string") req.body.password = ""

    if(req.body.username.trim() == "") errors = ["password/username no working"]
    if(req.body.password == "") errors = ["password/username no working"]

    if (errors.length) {
        return res.render("login", {errors})
    }

    const userInQuestionStatement = db.prepare("SELECT * FROM users WHERE USERNAME = ?")
    const userInQuestion = userInQuestionStatement.get(req.body.username)

    if (!userInQuestion) {
        errors = ["password/username no working"]
        return res.render("login", {errors})
     }

     const matchOrNot = bcrypt.compareSync(req.body.password, userInQuestion.password)
     if (!matchOrNot) {
        errors = ["password/username no working"]
        return res.render("login", {errors})
     }

     const ourTokenValue = jwt.sign({exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 , skyColor: "blue", userid: userInQuestion.id, username: userInQuestion.username}, process.env.JWTSECRET)


    res.cookie("ourSimpleApp", ourTokenValue, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        maxAge: 1000 * 60 * 60 * 24 

    })

    res.redirect("/")
}) 

app.post("/register",  (req,res) => {
    const errors = []

    if (typeof req.body.username !== "string") req.body.username = ""
    if (typeof req.body.password !== "string") req.body.password = ""

    req.body.username = req.body.username.trim()

    if(!req.body.username) errors.push("You must use an username")
    if(req.body.username && req.body.username.length < 3) errors.push ("Username should at least be 3 characters.")
    if(req.body.username && req.body.username.length > 10) errors.push ("Username should not be more than 10 characters.")
    if(req.body.username && !req.body.username.match(/^[a-zA-Z0-9]+$/)) errors.push("Username only accepts numbers and letters")

    //checks if username exsists already
    const usernameStatement = db.prepare("SELECT * FROM users WHERE username = ?")
    const usernameCheck = usernameStatement.get(req.body.username)

    if (usernameCheck) errors.push("That username has been taken")

    if(!req.body.password) errors.push("You must use an password")
    if(req.body.password && req.body.password.length < 8) errors.push ("Password should at least be 8 characters.")
    if(req.body.password && req.body.password.length > 70) errors.push ("Password should not be more than 70 characters.")    

    if (errors.length) {
      return res.render("homepage", {errors})
    }

    // save new user in database 
    const salt = bcrypt.genSaltSync(10)
    req.body.password = bcrypt.hashSync(req.body.password, salt)

    const ourStatement = db.prepare("INSERT INTO users (username, password) VALUES (?, ?)")
    const result = ourStatement.run(req.body.username, req.body.password)

    const lookupStatement = db.prepare("SELECT * FROM users WHERE ROWID = ?")
    const ourUser = lookupStatement.get(result.lastInsertRowid)

    // log the user in with cookies
    const ourTokenValue = jwt.sign({exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 , skyColor: "blue", userid: ourUser.id, username: ourUser.username}, process.env.JWTSECRET)


    res.cookie("ourSimpleApp", ourTokenValue, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        maxAge: 1000 * 60 * 60 * 24 

    })

    res.redirect("/")

   })

   // Show booking form
app.get("/book", (req, res) => {
    if (!req.user) {
      return res.redirect("/login")
    }
    res.render("book")
  })
  
  app.get("/bookings", (req, res) => {
    if (!req.user) {
      return res.redirect("/login")
    }
    
    const bookingsStatement = db.prepare(`
      SELECT *, 
      (quantity * price) as total_price 
      FROM bookings 
      WHERE user_id = ? 
      ORDER BY date, time
    `)
    const bookings = bookingsStatement.all(req.user.userid)
    
    // Calculate overall total
    const overallTotal = bookings.reduce((sum, booking) => sum + (booking.quantity * booking.price), 0)
    
    res.render("bookings", { 
      bookings, 
      overallTotal: overallTotal.toFixed(2) 
    })
  })
  
  app.post("/book", (req, res) => {
    if (!req.user) {
      return res.redirect("/login")
    }
    
    const errors = []
    
    // Validate inputs
    if (typeof req.body.title !== "string" || !req.body.title.trim()) {
      errors.push("Title is required")
    }
    
    if (typeof req.body.date !== "string" || !req.body.date.trim()) {
      errors.push("Date is required")
    }
    
    if (typeof req.body.time !== "string" || !req.body.time.trim()) {
      errors.push("Time is required")
    }
    
    // Validate quantity
    const quantity = parseInt(req.body.quantity) || 1
    if (quantity < 1) {
      errors.push("Quantity must be at least 1")
    }
    
    // Validate price
    const price = parseFloat(req.body.price) || 0
    if (price < 0) {
      errors.push("Price cannot be negative")
    }
    
    if (errors.length) {
      return res.render("book", { errors, booking: req.body })
    }
    
    // Calculate total price
    const total_price = quantity * price

    app.post("/booking/:id/update-quantity", (req, res) => {
      if (!req.user) {
        return res.redirect("/login")
      }
      
      const bookingId = req.params.id
      const newQuantity = parseInt(req.body.quantity)
      
      if (isNaN(newQuantity) || newQuantity < 1) {
        return res.redirect("/bookings")
      }
      
      // First, get the current booking to ensure it belongs to the user
      const checkBookingStatement = db.prepare("SELECT * FROM bookings WHERE id = ? AND user_id = ?")
      const booking = checkBookingStatement.get(bookingId, req.user.userid)
      
      if (booking) {
        const updateStatement = db.prepare(`
          UPDATE bookings 
          SET quantity = ?, 
              total_price = ? 
          WHERE id = ?
        `)
        updateStatement.run(
          newQuantity, 
          newQuantity * booking.price, 
          bookingId
        )
      }
      
      res.redirect("/bookings")
    })
    
    // Delete a booking
app.post("/booking/:id/delete", (req, res) => {
  if (!req.user) {
    return res.redirect("/login")
  }
  
  const bookingId = req.params.id
  
  // Ensure the booking belongs to the logged-in user
  const deleteStatement = db.prepare("DELETE FROM bookings WHERE id = ? AND user_id = ?")
  const result = deleteStatement.run(bookingId, req.user.userid)
  
  // Check if any row was actually deleted
  if (result.changes === 0) {
    // No booking found or not authorized
    console.log("No booking deleted - either not found or not authorized")
  }
  
  res.redirect("/bookings")
})



    // Save the booking
    const bookingStatement = db.prepare(`
      INSERT INTO bookings (
        user_id, title, date, time, description, 
        quantity, price, total_price, payment_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    bookingStatement.run(
      req.user.userid,
      req.body.title.trim(),
      req.body.date.trim(),
      req.body.time.trim(),
      (req.body.description || "").trim(),
      quantity,
      price,
      total_price,
      'pending' // Default payment status
    )
    
    res.redirect("/bookings")
  })

app.listen(3000)