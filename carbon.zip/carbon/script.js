function calculateFootprint() {
    let q1 = parseFloat(document.getElementById("q1").value) * parseFloat(document.getElementById("q2").value);
    let q3 = parseFloat(document.getElementById("q3").value) * 0.5;
    let q4 = 1 / parseFloat(document.getElementById("q4").value);
    let q5 = parseFloat(document.getElementById("q5").value) * parseFloat(document.getElementById("q6").value);
    let q7 = parseFloat(document.getElementById("q7").value) * 0.2;
    let q8 = parseFloat(document.getElementById("q8").value) * 0.15;
    let q9 = parseFloat(document.getElementById("q9").value) * 0.25;
    let q10 = parseFloat(document.getElementById("q10").value);
    let q11 = parseFloat(document.getElementById("q11").value) * 0.3;
    let q12 = parseFloat(document.getElementById("q12").value);
    let q13 = parseFloat(document.getElementById("q13").value) * 0.1;

    let totalFootprint = q1 + q3 + q4 + q5 + q7 + q8 + q9 + q10 + q11 + q12 + q13;

    let message = "";

    if (totalFootprint < 5) {
        message = "🌱 Great job! Your carbon footprint is **very low**. Keep up the eco-friendly habits!";
    } else if (totalFootprint >= 5 && totalFootprint < 10) {
        message = "⚖️ Your carbon footprint is **average**. Consider making small lifestyle changes to reduce emissions.";
    } else {
        message = "🔥 Your carbon footprint is **high**. Try to cut down on driving, energy usage, and waste to help the planet!";
    }

    document.getElementById("result").innerHTML = `
        <p>Your estimated carbon footprint: <strong>${totalFootprint.toFixed(2)} tons of CO₂ per year</strong></p>
        <p>${message}</p>
    `;
}
dashboard